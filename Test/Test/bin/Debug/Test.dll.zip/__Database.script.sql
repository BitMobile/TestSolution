
CREATE TABLE ___Metadata([Data] TEXT)
GO
CREATE TABLE ___Anchor([Data] TEXT)
GO
CREATE TABLE ___TranStatus([Id] TEXT PRIMARY KEY, [TableName] TEXT, [Status] INTEGER)
GO
CREATE TABLE ___UserInfo([UserId] TEXT PRIMARY KEY, [Email] TEXT)
GO
CREATE TABLE ___DbStatus([UserId] TEXT PRIMARY KEY, [LastSync] TEXT, [LastSyncError] TEXT)
GO
CREATE TABLE ___DbLocations([Id] TEXT PRIMARY KEY, [Latitude] REAL, [Longitude] REAL, [BeginTime] TEXT, [EndTime] TEXT, [Speed] REAL, [Direction] REAL, [SatellitesCount] INTEGER, [Altitude] REAL)
GO


CREATE TABLE [_Enum_StatusyEvents](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_StatusyEvents](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_StatusyEvents] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_StatusyEvents WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_StatusyEvents_IsTombstone] ON [_Enum_StatusyEvents]([IsTombstone])
GO



CREATE TABLE [_Enum_CheckListStatus](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_CheckListStatus](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_CheckListStatus] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_CheckListStatus WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_CheckListStatus_IsTombstone] ON [_Enum_CheckListStatus]([IsTombstone])
GO



CREATE TABLE [_Enum_FoReminders](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_FoReminders](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_FoReminders] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_FoReminders WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_FoReminders_IsTombstone] ON [_Enum_FoReminders]([IsTombstone])
GO



CREATE TABLE [_Enum_ResultEvent](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_ResultEvent](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_ResultEvent] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_ResultEvent WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_ResultEvent_IsTombstone] ON [_Enum_ResultEvent]([IsTombstone])
GO



CREATE TABLE [_Enum_StatsNeedNum](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_StatsNeedNum](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_StatsNeedNum] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_StatsNeedNum WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_StatsNeedNum_IsTombstone] ON [_Enum_StatsNeedNum]([IsTombstone])
GO



CREATE TABLE [_Enum_StatusImportance](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_StatusImportance](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_StatusImportance] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_StatusImportance WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_StatusImportance_IsTombstone] ON [_Enum_StatusImportance]([IsTombstone])
GO



CREATE TABLE [_Enum_TypesEvents](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_TypesEvents](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_TypesEvents] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_TypesEvents WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_TypesEvents_IsTombstone] ON [_Enum_TypesEvents]([IsTombstone])
GO



CREATE TABLE [_Enum_TypesDataParameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_TypesDataParameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_TypesDataParameters] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_TypesDataParameters WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_TypesDataParameters_IsTombstone] ON [_Enum_TypesDataParameters]([IsTombstone])
GO



CREATE TABLE [_Enum_StatusEquipment](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE TABLE [__Enum_StatusEquipment](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Name] TEXT NOT NULL
		,[Description] TEXT NOT NULL
	)
GO

CREATE VIEW [Enum_StatusEquipment] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Name]
		,[Description]
		FROM _Enum_StatusEquipment WHERE IsTombstone = 0
GO

CREATE INDEX [Enum_StatusEquipment_IsTombstone] ON [_Enum_StatusEquipment]([IsTombstone])
GO



CREATE TABLE [_Catalog_RIM](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Price] DECIMAL NULL
		,[Service] INTEGER NULL
		,[SKU] TEXT NULL
		,[Unit] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_RIM](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Price] DECIMAL NULL
		,[Service] INTEGER NULL
		,[SKU] TEXT NULL
		,[Unit] TEXT NULL
	)
GO

CREATE VIEW [Catalog_RIM] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[IsFolder]
		,[Parent]
		,[Description]
		,[Code]
		,[Price]
		,[Service]
		,[SKU]
		,[Unit]
		FROM _Catalog_RIM WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_RIM_IsTombstone] ON [_Catalog_RIM]([IsTombstone])
GO



CREATE TABLE [_Document_Reminder](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[Reminders] TEXT NULL
		,[ViewReminder] TEXT NULL
		,[Comment] TEXT NULL
	)
GO

CREATE TABLE [__Document_Reminder](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[Reminders] TEXT NULL
		,[ViewReminder] TEXT NULL
		,[Comment] TEXT NULL
	)
GO

CREATE VIEW [Document_Reminder] AS
	SELECT
	[IsDirty]
		,[Posted]
		,[Id]
		,[DeletionMark]
		,[Date]
		,[Number]
		,[Reminders]
		,[ViewReminder]
		,[Comment]
		FROM _Document_Reminder WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Reminder_IsTombstone] ON [_Document_Reminder]([IsTombstone])
GO


CREATE TABLE [_Document_Reminder_Photo](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[IDPhoto] TEXT NULL
	)
GO

CREATE TABLE [__Document_Reminder_Photo](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[IDPhoto] TEXT NULL
	)
GO

CREATE VIEW [Document_Reminder_Photo] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[IDPhoto]
		FROM _Document_Reminder_Photo WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Reminder_Photo_IsTombstone] ON [_Document_Reminder_Photo]([IsTombstone])
GO



CREATE TABLE [_Document_Event](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[ApplicationJustification] TEXT NULL
		,[Client] TEXT NOT NULL
		,[DivisionSource] TEXT NULL
		,[KindEvent] TEXT NULL
		,[AnySale] INTEGER NULL
		,[AnyProblem] INTEGER NULL
		,[StartDatePlan] TEXT NULL
		,[EndDatePlan] TEXT NULL
		,[ActualStartDate] TEXT NULL
		,[ActualEndDate] TEXT NULL
		,[Author] TEXT NULL
		,[UserMA] TEXT NOT NULL
		,[Comment] TEXT NULL
		,[DetailedDescription] TEXT NULL
		,[CommentContractor] TEXT NULL
		,[TargInteractions] TEXT NULL
		,[ResultInteractions] TEXT NULL
		,[Status] TEXT NULL
		,[Latitude] DECIMAL NULL
		,[Longitude] DECIMAL NULL
		,[GPSTime] TEXT NULL
		,[ContactVisiting] TEXT NULL
		,[TypesDepartures] TEXT NULL
		,[Importance] TEXT NOT NULL
	)
GO

CREATE TABLE [__Document_Event](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[ApplicationJustification] TEXT NULL
		,[Client] TEXT NOT NULL
		,[DivisionSource] TEXT NULL
		,[KindEvent] TEXT NULL
		,[AnySale] INTEGER NULL
		,[AnyProblem] INTEGER NULL
		,[StartDatePlan] TEXT NULL
		,[EndDatePlan] TEXT NULL
		,[ActualStartDate] TEXT NULL
		,[ActualEndDate] TEXT NULL
		,[Author] TEXT NULL
		,[UserMA] TEXT NOT NULL
		,[Comment] TEXT NULL
		,[DetailedDescription] TEXT NULL
		,[CommentContractor] TEXT NULL
		,[TargInteractions] TEXT NULL
		,[ResultInteractions] TEXT NULL
		,[Status] TEXT NULL
		,[Latitude] DECIMAL NULL
		,[Longitude] DECIMAL NULL
		,[GPSTime] TEXT NULL
		,[ContactVisiting] TEXT NULL
		,[TypesDepartures] TEXT NULL
		,[Importance] TEXT NOT NULL
	)
GO

CREATE VIEW [Document_Event] AS
	SELECT
	[IsDirty]
		,[Posted]
		,[Id]
		,[DeletionMark]
		,[Date]
		,[Number]
		,[ApplicationJustification]
		,[Client]
		,[DivisionSource]
		,[KindEvent]
		,[AnySale]
		,[AnyProblem]
		,[StartDatePlan]
		,[EndDatePlan]
		,[ActualStartDate]
		,[ActualEndDate]
		,[Author]
		,[UserMA]
		,[Comment]
		,[DetailedDescription]
		,[CommentContractor]
		,[TargInteractions]
		,[ResultInteractions]
		,[Status]
		,[Latitude]
		,[Longitude]
		,[GPSTime]
		,[ContactVisiting]
		,[TypesDepartures]
		,[Importance]
		FROM _Document_Event WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_IsTombstone] ON [_Document_Event]([IsTombstone])
GO


CREATE TABLE [_Document_Event_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE TABLE [__Document_Event_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE VIEW [Document_Event_Files] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Ref]
		,[LineNumber]
		,[FullFileName]
		,[FileName]
		FROM _Document_Event_Files WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_Files_IsTombstone] ON [_Document_Event_Files]([IsTombstone])
GO


CREATE TABLE [_Document_Event_Equipments](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Equipment] TEXT NOT NULL
		,[Terget] TEXT NULL
		,[Result] TEXT NULL
		,[Comment] TEXT NULL
		,[SID] TEXT NULL
	)
GO

CREATE TABLE [__Document_Event_Equipments](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Equipment] TEXT NOT NULL
		,[Terget] TEXT NULL
		,[Result] TEXT NULL
		,[Comment] TEXT NULL
		,[SID] TEXT NULL
	)
GO

CREATE VIEW [Document_Event_Equipments] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Equipment]
		,[Terget]
		,[Result]
		,[Comment]
		,[SID]
		FROM _Document_Event_Equipments WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_Equipments_IsTombstone] ON [_Document_Event_Equipments]([IsTombstone])
GO


CREATE TABLE [_Document_Event_Photos](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[UIDPhoto] TEXT NULL
		,[Equipment] TEXT NULL
	)
GO

CREATE TABLE [__Document_Event_Photos](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[UIDPhoto] TEXT NULL
		,[Equipment] TEXT NULL
	)
GO

CREATE VIEW [Document_Event_Photos] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[UIDPhoto]
		,[Equipment]
		FROM _Document_Event_Photos WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_Photos_IsTombstone] ON [_Document_Event_Photos]([IsTombstone])
GO


CREATE TABLE [_Document_Event_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Document_Event_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Document_Event_Parameters] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Parameter]
		,[Val]
		FROM _Document_Event_Parameters WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_Parameters_IsTombstone] ON [_Document_Event_Parameters]([IsTombstone])
GO


CREATE TABLE [_Document_Event_CheckList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Action] TEXT NULL
		,[CheckListRef] TEXT NULL
		,[Result] TEXT NULL
		,[ActionType] TEXT NULL
		,[Required] INTEGER NULL
	)
GO

CREATE TABLE [__Document_Event_CheckList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Action] TEXT NULL
		,[CheckListRef] TEXT NULL
		,[Result] TEXT NULL
		,[ActionType] TEXT NULL
		,[Required] INTEGER NULL
	)
GO

CREATE VIEW [Document_Event_CheckList] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Action]
		,[CheckListRef]
		,[Result]
		,[ActionType]
		,[Required]
		FROM _Document_Event_CheckList WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_CheckList_IsTombstone] ON [_Document_Event_CheckList]([IsTombstone])
GO


CREATE TABLE [_Document_Event_TypeDepartures](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[TypeDeparture] TEXT NULL
		,[Active] INTEGER NULL
	)
GO

CREATE TABLE [__Document_Event_TypeDepartures](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[TypeDeparture] TEXT NULL
		,[Active] INTEGER NULL
	)
GO

CREATE VIEW [Document_Event_TypeDepartures] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[TypeDeparture]
		,[Active]
		FROM _Document_Event_TypeDepartures WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_TypeDepartures_IsTombstone] ON [_Document_Event_TypeDepartures]([IsTombstone])
GO


CREATE TABLE [_Document_Event_ServicesMaterials](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[SKU] TEXT NULL
		,[Price] DECIMAL NULL
		,[AmountPlan] DECIMAL NULL
		,[SumPlan] DECIMAL NULL
		,[AmountFact] DECIMAL NULL
		,[SumFact] DECIMAL NULL
	)
GO

CREATE TABLE [__Document_Event_ServicesMaterials](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[SKU] TEXT NULL
		,[Price] DECIMAL NULL
		,[AmountPlan] DECIMAL NULL
		,[SumPlan] DECIMAL NULL
		,[AmountFact] DECIMAL NULL
		,[SumFact] DECIMAL NULL
	)
GO

CREATE VIEW [Document_Event_ServicesMaterials] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[SKU]
		,[Price]
		,[AmountPlan]
		,[SumPlan]
		,[AmountFact]
		,[SumFact]
		FROM _Document_Event_ServicesMaterials WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Event_ServicesMaterials_IsTombstone] ON [_Document_Event_ServicesMaterials]([IsTombstone])
GO



CREATE TABLE [_Catalog_SKU](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_SKU](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE VIEW [Catalog_SKU] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[IsFolder]
		,[Parent]
		,[Description]
		,[Code]
		FROM _Catalog_SKU WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_SKU_IsTombstone] ON [_Catalog_SKU]([IsTombstone])
GO



CREATE TABLE [_Catalog_ServiceAgreement](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Client] TEXT NULL
		,[Organization] TEXT NULL
		,[DateStart] TEXT NULL
		,[DateEnd] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_ServiceAgreement](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Client] TEXT NULL
		,[Organization] TEXT NULL
		,[DateStart] TEXT NULL
		,[DateEnd] TEXT NULL
	)
GO

CREATE VIEW [Catalog_ServiceAgreement] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[Client]
		,[Organization]
		,[DateStart]
		,[DateEnd]
		FROM _Catalog_ServiceAgreement WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_ServiceAgreement_IsTombstone] ON [_Catalog_ServiceAgreement]([IsTombstone])
GO



CREATE TABLE [_Catalog_EquipmentOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE TABLE [__Catalog_EquipmentOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE VIEW [Catalog_EquipmentOptions] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[DataTypeParameter]
		,[DisplayingBMA]
		,[EditingBMA]
		FROM _Catalog_EquipmentOptions WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_EquipmentOptions_IsTombstone] ON [_Catalog_EquipmentOptions]([IsTombstone])
GO


CREATE TABLE [_Catalog_EquipmentOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_EquipmentOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_EquipmentOptions_ListValues] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Val]
		FROM _Catalog_EquipmentOptions_ListValues WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_EquipmentOptions_ListValues_IsTombstone] ON [_Catalog_EquipmentOptions_ListValues]([IsTombstone])
GO



CREATE TABLE [_Catalog_Equipment](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[SKU] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Equipment](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[SKU] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Equipment] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[SKU]
		FROM _Catalog_Equipment WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Equipment_IsTombstone] ON [_Catalog_Equipment]([IsTombstone])
GO


CREATE TABLE [_Catalog_Equipment_Equiements](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Period] TEXT NULL
		,[Clients] TEXT NULL
		,[Ref] TEXT NOT NULL
		,[StatusEquiement] TEXT NULL
		,[ContractSale] TEXT NULL
		,[CantractService] TEXT NULL
		,[ContactForEquiemnt] TEXT NULL
		,[Info] TEXT NULL
		,[Equiement] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Equipment_Equiements](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Period] TEXT NULL
		,[Clients] TEXT NULL
		,[Ref] TEXT NOT NULL
		,[StatusEquiement] TEXT NULL
		,[ContractSale] TEXT NULL
		,[CantractService] TEXT NULL
		,[ContactForEquiemnt] TEXT NULL
		,[Info] TEXT NULL
		,[Equiement] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Equipment_Equiements] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Period]
		,[Clients]
		,[Ref]
		,[StatusEquiement]
		,[ContractSale]
		,[CantractService]
		,[ContactForEquiemnt]
		,[Info]
		,[Equiement]
		FROM _Catalog_Equipment_Equiements WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Equipment_Equiements_IsTombstone] ON [_Catalog_Equipment_Equiements]([IsTombstone])
GO


CREATE TABLE [_Catalog_Equipment_EquiementsHistory](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Period] TEXT NULL
		,[Client] TEXT NULL
		,[Ref] TEXT NOT NULL
		,[Equiements] TEXT NULL
		,[Target] TEXT NULL
		,[Result] TEXT NULL
		,[ObjectGet] TEXT NULL
		,[Comment] TEXT NULL
		,[Executor] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Equipment_EquiementsHistory](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Period] TEXT NULL
		,[Client] TEXT NULL
		,[Ref] TEXT NOT NULL
		,[Equiements] TEXT NULL
		,[Target] TEXT NULL
		,[Result] TEXT NULL
		,[ObjectGet] TEXT NULL
		,[Comment] TEXT NULL
		,[Executor] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Equipment_EquiementsHistory] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Period]
		,[Client]
		,[Ref]
		,[Equiements]
		,[Target]
		,[Result]
		,[ObjectGet]
		,[Comment]
		,[Executor]
		FROM _Catalog_Equipment_EquiementsHistory WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Equipment_EquiementsHistory_IsTombstone] ON [_Catalog_Equipment_EquiementsHistory]([IsTombstone])
GO


CREATE TABLE [_Catalog_Equipment_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Equipment_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Equipment_Files] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Ref]
		,[LineNumber]
		,[FullFileName]
		,[FileName]
		FROM _Catalog_Equipment_Files WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Equipment_Files_IsTombstone] ON [_Catalog_Equipment_Files]([IsTombstone])
GO


CREATE TABLE [_Catalog_Equipment_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Equipment_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Equipment_Parameters] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Parameter]
		,[Val]
		FROM _Catalog_Equipment_Parameters WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Equipment_Parameters_IsTombstone] ON [_Catalog_Equipment_Parameters]([IsTombstone])
GO



CREATE TABLE [_Catalog_Client](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Latitude] DECIMAL NULL
		,[Longitude] DECIMAL NULL
		,[Address] TEXT NULL
		,[Contractor] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Client](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Latitude] DECIMAL NULL
		,[Longitude] DECIMAL NULL
		,[Address] TEXT NULL
		,[Contractor] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Client] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[Latitude]
		,[Longitude]
		,[Address]
		,[Contractor]
		FROM _Catalog_Client WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Client_IsTombstone] ON [_Catalog_Client]([IsTombstone])
GO


CREATE TABLE [_Catalog_Client_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Client_Files](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Ref] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[FullFileName] TEXT NULL
		,[FileName] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Client_Files] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Ref]
		,[LineNumber]
		,[FullFileName]
		,[FileName]
		FROM _Catalog_Client_Files WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Client_Files_IsTombstone] ON [_Catalog_Client_Files]([IsTombstone])
GO


CREATE TABLE [_Catalog_Client_Contacts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Contact] TEXT NOT NULL
		,[Actual] INTEGER NULL
	)
GO

CREATE TABLE [__Catalog_Client_Contacts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Contact] TEXT NOT NULL
		,[Actual] INTEGER NULL
	)
GO

CREATE VIEW [Catalog_Client_Contacts] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Contact]
		,[Actual]
		FROM _Catalog_Client_Contacts WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Client_Contacts_IsTombstone] ON [_Catalog_Client_Contacts]([IsTombstone])
GO


CREATE TABLE [_Catalog_Client_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Client_Parameters](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Parameter] TEXT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Client_Parameters] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Parameter]
		,[Val]
		FROM _Catalog_Client_Parameters WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Client_Parameters_IsTombstone] ON [_Catalog_Client_Parameters]([IsTombstone])
GO



CREATE TABLE [_Catalog_SettingMobileApplication](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataType] TEXT NULL
		,[LogicValue] INTEGER NULL
		,[NumericValue] INTEGER NULL
	)
GO

CREATE TABLE [__Catalog_SettingMobileApplication](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataType] TEXT NULL
		,[LogicValue] INTEGER NULL
		,[NumericValue] INTEGER NULL
	)
GO

CREATE VIEW [Catalog_SettingMobileApplication] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[DataType]
		,[LogicValue]
		,[NumericValue]
		FROM _Catalog_SettingMobileApplication WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_SettingMobileApplication_IsTombstone] ON [_Catalog_SettingMobileApplication]([IsTombstone])
GO



CREATE TABLE [_Catalog_User](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[UserName] TEXT NOT NULL
		,[Password] TEXT NOT NULL
		,[UserDB] TEXT NULL
		,[EMail] TEXT NULL
		,[UserID] TEXT NULL
		,[Phone] TEXT NULL
		,[Role] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_User](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[UserName] TEXT NOT NULL
		,[Password] TEXT NOT NULL
		,[UserDB] TEXT NULL
		,[EMail] TEXT NULL
		,[UserID] TEXT NULL
		,[Phone] TEXT NULL
		,[Role] TEXT NULL
	)
GO

CREATE VIEW [Catalog_User] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[UserName]
		,[Password]
		,[UserDB]
		,[EMail]
		,[UserID]
		,[Phone]
		,[Role]
		FROM _Catalog_User WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_User_IsTombstone] ON [_Catalog_User]([IsTombstone])
GO


CREATE TABLE [_Catalog_User_Bag](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Materials] TEXT NULL
		,[Count] DECIMAL NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
	)
GO

CREATE TABLE [__Catalog_User_Bag](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Materials] TEXT NULL
		,[Count] DECIMAL NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
	)
GO

CREATE VIEW [Catalog_User_Bag] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Materials]
		,[Count]
		,[LineNumber]
		,[Ref]
		FROM _Catalog_User_Bag WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_User_Bag_IsTombstone] ON [_Catalog_User_Bag]([IsTombstone])
GO


CREATE TABLE [_Catalog_User_RemainsNorms](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Materials] TEXT NULL
		,[Count] DECIMAL NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
	)
GO

CREATE TABLE [__Catalog_User_RemainsNorms](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[Materials] TEXT NULL
		,[Count] DECIMAL NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
	)
GO

CREATE VIEW [Catalog_User_RemainsNorms] AS
	SELECT
	[IsDirty]
		,[Id]
		,[Materials]
		,[Count]
		,[LineNumber]
		,[Ref]
		FROM _Catalog_User_RemainsNorms WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_User_RemainsNorms_IsTombstone] ON [_Catalog_User_RemainsNorms]([IsTombstone])
GO



CREATE TABLE [_Catalog_Accounts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Accounts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[IsFolder] INTEGER NULL
		,[Parent] TEXT NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Accounts] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[IsFolder]
		,[Parent]
		,[Description]
		,[Code]
		FROM _Catalog_Accounts WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Accounts_IsTombstone] ON [_Catalog_Accounts]([IsTombstone])
GO



CREATE TABLE [_Catalog_ClientOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE TABLE [__Catalog_ClientOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE VIEW [Catalog_ClientOptions] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[DataTypeParameter]
		,[DisplayingBMA]
		,[EditingBMA]
		FROM _Catalog_ClientOptions WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_ClientOptions_IsTombstone] ON [_Catalog_ClientOptions]([IsTombstone])
GO


CREATE TABLE [_Catalog_ClientOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_ClientOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_ClientOptions_ListValues] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Val]
		FROM _Catalog_ClientOptions_ListValues WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_ClientOptions_ListValues_IsTombstone] ON [_Catalog_ClientOptions_ListValues]([IsTombstone])
GO



CREATE TABLE [_Catalog_EventOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE TABLE [__Catalog_EventOptions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[DataTypeParameter] TEXT NOT NULL
		,[DisplayingBMA] INTEGER NULL
		,[EditingBMA] INTEGER NULL
	)
GO

CREATE VIEW [Catalog_EventOptions] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[DataTypeParameter]
		,[DisplayingBMA]
		,[EditingBMA]
		FROM _Catalog_EventOptions WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_EventOptions_IsTombstone] ON [_Catalog_EventOptions]([IsTombstone])
GO


CREATE TABLE [_Catalog_EventOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_EventOptions_ListValues](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_EventOptions_ListValues] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Val]
		FROM _Catalog_EventOptions_ListValues WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_EventOptions_ListValues_IsTombstone] ON [_Catalog_EventOptions_ListValues]([IsTombstone])
GO



CREATE TABLE [_Document_CheckList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[Description] TEXT NULL
		,[Project] TEXT NULL
		,[Status] TEXT NULL
	)
GO

CREATE TABLE [__Document_CheckList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[Description] TEXT NULL
		,[Project] TEXT NULL
		,[Status] TEXT NULL
	)
GO

CREATE VIEW [Document_CheckList] AS
	SELECT
	[IsDirty]
		,[Posted]
		,[Id]
		,[DeletionMark]
		,[Date]
		,[Number]
		,[Description]
		,[Project]
		,[Status]
		FROM _Document_CheckList WHERE IsTombstone = 0
GO

CREATE INDEX [Document_CheckList_IsTombstone] ON [_Document_CheckList]([IsTombstone])
GO


CREATE TABLE [_Document_CheckList_Actions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Action] TEXT NULL
		,[Required] INTEGER NULL
	)
GO

CREATE TABLE [__Document_CheckList_Actions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Action] TEXT NULL
		,[Required] INTEGER NULL
	)
GO

CREATE VIEW [Document_CheckList_Actions] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Action]
		,[Required]
		FROM _Document_CheckList_Actions WHERE IsTombstone = 0
GO

CREATE INDEX [Document_CheckList_Actions_IsTombstone] ON [_Document_CheckList_Actions]([IsTombstone])
GO



CREATE TABLE [_Catalog_Actions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[ActionType] TEXT NOT NULL
	)
GO

CREATE TABLE [__Catalog_Actions](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[ActionType] TEXT NOT NULL
	)
GO

CREATE VIEW [Catalog_Actions] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[ActionType]
		FROM _Catalog_Actions WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Actions_IsTombstone] ON [_Catalog_Actions]([IsTombstone])
GO


CREATE TABLE [_Catalog_Actions_ValueList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Actions_ValueList](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[Val] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Actions_ValueList] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[Val]
		FROM _Catalog_Actions_ValueList WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Actions_ValueList_IsTombstone] ON [_Catalog_Actions_ValueList]([IsTombstone])
GO



CREATE TABLE [_Catalog_Contacts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Position] TEXT NULL
		,[Tel] TEXT NULL
		,[EMail] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_Contacts](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
		,[Position] TEXT NULL
		,[Tel] TEXT NULL
		,[EMail] TEXT NULL
	)
GO

CREATE VIEW [Catalog_Contacts] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		,[Position]
		,[Tel]
		,[EMail]
		FROM _Catalog_Contacts WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_Contacts_IsTombstone] ON [_Catalog_Contacts]([IsTombstone])
GO



CREATE TABLE [_Document_NeedMat](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[DocIn] TEXT NULL
		,[StatsNeed] TEXT NOT NULL
		,[SR] TEXT NOT NULL
		,[FillFull] INTEGER NULL
		,[SRMComment] TEXT NULL
		,[SRComment] TEXT NULL
	)
GO

CREATE TABLE [__Document_NeedMat](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[Number] TEXT NULL
		,[DocIn] TEXT NULL
		,[StatsNeed] TEXT NOT NULL
		,[SR] TEXT NOT NULL
		,[FillFull] INTEGER NULL
		,[SRMComment] TEXT NULL
		,[SRComment] TEXT NULL
	)
GO

CREATE VIEW [Document_NeedMat] AS
	SELECT
	[IsDirty]
		,[Posted]
		,[Id]
		,[DeletionMark]
		,[Date]
		,[Number]
		,[DocIn]
		,[StatsNeed]
		,[SR]
		,[FillFull]
		,[SRMComment]
		,[SRComment]
		FROM _Document_NeedMat WHERE IsTombstone = 0
GO

CREATE INDEX [Document_NeedMat_IsTombstone] ON [_Document_NeedMat]([IsTombstone])
GO


CREATE TABLE [_Document_NeedMat_Matireals](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[SKU] TEXT NOT NULL
		,[Count] DECIMAL NOT NULL
	)
GO

CREATE TABLE [__Document_NeedMat_Matireals](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Id] TEXT NOT NULL
		,[LineNumber] INTEGER NULL
		,[Ref] TEXT NOT NULL
		,[SKU] TEXT NOT NULL
		,[Count] DECIMAL NOT NULL
	)
GO

CREATE VIEW [Document_NeedMat_Matireals] AS
	SELECT
	[IsDirty]
		,[Id]
		,[LineNumber]
		,[Ref]
		,[SKU]
		,[Count]
		FROM _Document_NeedMat_Matireals WHERE IsTombstone = 0
GO

CREATE INDEX [Document_NeedMat_Matireals_IsTombstone] ON [_Document_NeedMat_Matireals]([IsTombstone])
GO



CREATE TABLE [_Catalog_TypesDepartures](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE TABLE [__Catalog_TypesDepartures](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Predefined] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Description] TEXT NOT NULL
		,[Code] TEXT NULL
	)
GO

CREATE VIEW [Catalog_TypesDepartures] AS
	SELECT
	[IsDirty]
		,[Predefined]
		,[Id]
		,[DeletionMark]
		,[Description]
		,[Code]
		FROM _Catalog_TypesDepartures WHERE IsTombstone = 0
GO

CREATE INDEX [Catalog_TypesDepartures_IsTombstone] ON [_Catalog_TypesDepartures]([IsTombstone])
GO


