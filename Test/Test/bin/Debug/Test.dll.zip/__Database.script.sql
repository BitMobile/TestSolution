
CREATE TABLE ___Metadata([Data] TEXT)
GO
CREATE TABLE ___Anchor([Data] TEXT)
GO
CREATE TABLE ___TranStatus([Id] TEXT PRIMARY KEY, [TableName] TEXT, [Status] INTEGER)
GO
CREATE TABLE ___UserInfo([UserId] TEXT PRIMARY KEY, [Email] TEXT)
GO
CREATE TABLE ___DbStatus([UserId] TEXT PRIMARY KEY, [LastSync] TEXT, [LastSyncError] TEXT)
GO
CREATE TABLE ___DbLocations([Id] TEXT PRIMARY KEY, [Latitude] REAL, [Longitude] REAL, [BeginTime] TEXT, [EndTime] TEXT, [Speed] REAL, [Direction] REAL, [SatellitesCount] INTEGER, [Altitude] REAL)
GO


CREATE TABLE [_Document_Photos](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[FileName] TEXT NULL
		,[Link] TEXT NULL
	)
GO

CREATE TABLE [__Document_Photos](
	[IsTombstone] INTEGER,[IsDirty] INTEGER
		,[Posted] INTEGER NULL
		,[Id] TEXT NOT NULL
		,[DeletionMark] INTEGER NULL
		,[Date] TEXT NOT NULL
		,[FileName] TEXT NULL
		,[Link] TEXT NULL
	)
GO

CREATE VIEW [Document_Photos] AS
	SELECT
	[IsDirty]
		,[Posted]
		,[Id]
		,[DeletionMark]
		,[Date]
		,[FileName]
		,[Link]
		FROM _Document_Photos WHERE IsTombstone = 0
GO

CREATE INDEX [Document_Photos_IsTombstone] ON [_Document_Photos]([IsTombstone])
GO


